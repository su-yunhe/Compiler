# primaryExp 基本表达式包

`<PrimaryExp>`  -> `'(' <Exp> ')' | <LVal> | <Number>`

## PrimaryExpExp

## Lval

## Number