package enums;

public enum ReturnType {
    NONE, VOID, INT
}
