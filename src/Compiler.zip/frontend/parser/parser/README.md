# FIRST集

CompUnit

Decl 声明类
CONSTTK INTTK || INTTK


DeclEle 声明类文法基类接口

ConstDecl 常量声明类

ConstDef 常数定义类


ConstInitVal 常量初值类

ConstInitValEle 常量初值类文法基类接口

ConstInitValMulti 常量数组初值类

FuncDef
INTTK IDENFR || VOIDTK IDENFR

MainFuncDef