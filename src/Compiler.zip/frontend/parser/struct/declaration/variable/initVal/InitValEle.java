package frontend.parser.struct.declaration.variable.initVal;

/**
 * 变量初值类文法基类
 * 被 Exp
 * 和 InitValMulti = '{' [ InitVal { ',' InitVal } ] '}'// 1.表达式初值 2.一维数组初值 3.二维数组初值
 * @author SYH
 * @date 2023/09/26
 */
public interface InitValEle {
}
