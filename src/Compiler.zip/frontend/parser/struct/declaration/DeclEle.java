package frontend.parser.struct.declaration;

/**
 * 声明类文法基类接口
 * 被 ConstDecl(常量声明) 和 VarDecl(变量声明) 继承
 * @author SYH
 * @date 2023/09/26
 */
public interface DeclEle {
}
