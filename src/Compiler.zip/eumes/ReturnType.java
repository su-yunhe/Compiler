package eumes;

public enum ReturnType {
    NONE, VOID, INT
}
